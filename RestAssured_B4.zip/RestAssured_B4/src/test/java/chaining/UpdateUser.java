package chaining;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class UpdateUser {
  @Parameters({"appBaseURI", "token"})
  @Test
  public void udpateUserTest(String appUrl, String bearerToken, ITestContext context) {
	  //baseURI = "https://gorest.co.in";
	  baseURI =  appUrl;
	  //String bearerToken = "5fe3239763fb26aff8598105c765a17f480a1c89738a1031d90a79ae108f3d31";
	  Object userIdObj = context.getSuite().getAttribute("user_id");
	  if (userIdObj == null ) {
		  System.out.println("user ID is null");
		  userIdObj = context.getAttribute("user_id");
	  }
	  int userId = (int) userIdObj;
	  Faker faker = new Faker();
	  JSONObject data = new JSONObject() ;
	  data.put("name", faker.name().fullName());
	  data.put("gender", "Male");
	  data.put("email", faker.internet().emailAddress());
	  data.put("status", "Active");
	  
	  given()
	  	.contentType("application/json")
	  	.body(data.toJSONString())
	  	.headers("Authorization", "Bearer "+ bearerToken)
	  	.pathParam("id", userId)
	  .when()
	  	.put("/public/v2/users/{id}")
	  .then()
	  	.statusCode(200)
	  	.log().all();
  }
}
