package chaining;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

public class GetUser {
	
  @Parameters({"appBaseURI", "token"})
  @Test
  public void getUserTest(String appUrl, String bearerToken,ITestContext context) {
	  baseURI = "https://gorest.co.in";
	  //String bearerToken = "5fe3239763fb26aff8598105c765a17f480a1c89738a1031d90a79ae108f3d31";
	  Object userIdObj = context.getSuite().getAttribute("user_id");
	  if (userIdObj == null ) {
		  System.out.println("user ID is null");
		  userIdObj = context.getAttribute("user_id");
	  }
	  int userId = (int) userIdObj;
	  System.out.println("ID to fetch: "+ userId);
	  given()
	  	.contentType("application/json")
	  	.headers("Authorization", "Bearer "+ bearerToken)
	  	.pathParam("id", userId)
	  .when()
	  	.get("/public/v2/users/{id}")
	  .then()
	  	.statusCode(200)
	  	.log().all();
	  	
  }
}
