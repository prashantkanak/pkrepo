package chaining;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

public class CreateUser {
  
  @Parameters({"appBaseURI", "token"})
  @Test
  public void createUserTest(String appUrl, String bearerToken, ITestContext context) {
	  //baseURI = "https://gorest.co.in";
	  baseURI =  appUrl;
	  //String bearerToken = "5fe3239763fb26aff8598105c765a17f480a1c89738a1031d90a79ae108f3d31";
	  Faker faker = new Faker();
	  JSONObject data = new JSONObject() ;
	  data.put("name", faker.name().fullName());
	  data.put("gender", "Male");
	  data.put("email", faker.internet().emailAddress());
	  data.put("status", "inactive");
	 
	  //3430554
	  int id = given()
	  	.headers("Authorization", "Bearer "+ bearerToken)
	  	.contentType("application/json")
	  	.body(data.toJSONString())
	  .when()
	  	.post("/public/v2/users")
	  .then()
	  	.statusCode(201)
	  	.log().all()
	  	.extract().jsonPath().getInt("id");
	  //context.setAttribute("user_id", "12345");
	  context.getSuite().setAttribute("user_id", id);
	  System.out.println("Generated Id : "+id);
  }
}
