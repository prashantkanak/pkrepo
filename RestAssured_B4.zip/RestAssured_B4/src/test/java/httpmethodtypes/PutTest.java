package httpmethodtypes;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class PutTest {
	
	@Test
	public void testPut () {
		JSONObject json = new JSONObject();
		json.put("name", "Joe");
		json.put("job", "Dev");
		System.out.println(json);
		
		baseURI = "https://reqres.in";
		
		given()
			.contentType("application/json")
			.accept(ContentType.JSON)
			.body(json.toJSONString())
		.when()
			.put("/api/users/2")
		.then()
			.statusCode(200)
			.log()
			.all();
	}
}	
