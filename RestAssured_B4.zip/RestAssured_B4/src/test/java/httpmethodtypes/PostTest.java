package httpmethodtypes;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

public class PostTest {
	
	@Test
	public void postTest() {
		JSONObject json = new JSONObject();
		json.put("name", "Joe");
		json.put("job", "master");
		System.out.println(json);
		
		baseURI = "https://reqres.in";
		
		given()
			.contentType("application/json")
			.accept(ContentType.JSON)
			.body(json.toJSONString())
		.when()
			.post("/api/users")
		.then()
			.statusCode(201)
			.log()
			.all();
		
	}
}
