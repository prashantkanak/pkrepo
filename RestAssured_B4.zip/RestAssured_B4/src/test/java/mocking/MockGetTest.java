package mocking;

import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import static io.restassured.RestAssured.*;

public class MockGetTest {
	
	@Test
	public void testMockGetTest() {
		baseURI = "http://localhost:3001";
		given()
			.queryParam("page", 2)
		.when()
			.get("/api/users")
		.then()
			.statusCode(200)
			.log().all();
	}
}
