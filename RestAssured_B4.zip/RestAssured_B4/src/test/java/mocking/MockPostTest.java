package mocking;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class MockPostTest {
	
	@Test
	public void testMockPostTest() {
		baseURI = "http://localhost:3001";
		 Faker faker = new Faker();
		  JSONObject data = new JSONObject() ;
		  data.put("name", faker.name().fullName());
		  data.put("gender", "Male");
		  data.put("email", faker.internet().emailAddress());
		  data.put("status", "inactive");
		  
		given()
			.body(data.toJSONString())
			.contentType("application/json")
		.when()
			.post("/api/users")
		.then()
			.statusCode(200)
			.log().all();
	}
}
