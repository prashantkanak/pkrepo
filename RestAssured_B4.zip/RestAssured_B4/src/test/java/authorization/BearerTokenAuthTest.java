package authorization;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class BearerTokenAuthTest {
	
	@Test
	public void bearerTokenAuthTest() {
		String token = "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";
		baseURI = "https://api.github.com";
		
		given()
			.headers("Authorization", "Bearer "+ token)
		.when()
			.get("/user/repos")
		.then()
			.statusCode(200)
			.log().all();
	}
}
