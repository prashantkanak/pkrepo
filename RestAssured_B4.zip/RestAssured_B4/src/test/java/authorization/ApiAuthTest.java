package authorization;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class ApiAuthTest {

	@Test
	public void apiAuthTest() {
		
		baseURI = "https://api.openweathermap.org";
		//a10ccf1243ab4f4988ef498c3271667d
		given()
			.queryParam("appid", "3dc4461e41e09433623fb5f7aa20200f")
			.queryParam("q", "Pune")
			.queryParam("cnt", "7")
			
		.when()
			.get("/data/2.5/forecast/daily")
		.then()
			
			.log().all();
	}
}
