package authorization;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;

public class BasicAuthTest {

	@Test
	public void basicAuthTest() {
		baseURI = "https://postman-echo.com";
		
		given()
			.auth().basic("postman", "password")
		.when()
			.get("/basic-auth")
		.then()
			.statusCode(200)
			.body("authenticated", equalTo(true))
			.log().all();
			
	}
}
